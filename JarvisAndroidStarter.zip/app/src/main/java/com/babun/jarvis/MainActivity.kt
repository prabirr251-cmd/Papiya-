package com.babun.jarvis

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import okhttp3.Call
import okhttp3.Callback
import okhttp3.HttpUrl.Companion.toHttpUrl
import okio.ByteString
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

class MainActivity : Activity() {
    private val workerBase = "https://probir.prabirr251.workers.dev"
    // Replace this placeholder with your APP_TOKEN locally. Never share it in screenshots or chat.
    private val appToken = "PASTE_YOUR_APP_TOKEN_HERE"

    private val client = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(0, TimeUnit.MILLISECONDS)
        .build()

    private lateinit var status: TextView
    private lateinit var logView: TextView
    private var socket: WebSocket? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 32, 24, 24)
            setBackgroundColor(Color.rgb(15, 18, 30))
        }
        val title = TextView(this).apply {
            text = "JARVIS • Live connection test"
            textSize = 24f
            setTextColor(Color.WHITE)
        }
        status = TextView(this).apply {
            text = "Ready. Tap Connect to test token + WebSocket."
            textSize = 16f
            setTextColor(Color.rgb(190, 220, 255))
            setPadding(0, 20, 0, 20)
        }
        val connect = Button(this).apply {
            text = "Connect to Gemini Live"
            setOnClickListener { fetchTokenAndConnect() }
        }
        val disconnect = Button(this).apply {
            text = "Disconnect"
            setOnClickListener {
                socket?.close(1000, "User disconnected")
                socket = null
                setStatus("Disconnected.")
            }
        }
        logView = TextView(this).apply {
            textSize = 13f
            setTextColor(Color.LTGRAY)
        }
        val scroll = ScrollView(this).apply {
            addView(logView)
        }
        layout.addView(title)
        layout.addView(status)
        layout.addView(connect)
        layout.addView(disconnect)
        layout.addView(scroll, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f
        ))
        setContentView(layout)
    }

    private fun fetchTokenAndConnect() {
        if (appToken == "PASTE_YOUR_APP_TOKEN_HERE") {
            setStatus("Setup needed: enter your APP_TOKEN in MainActivity.kt.")
            return
        }
        setStatus("Requesting a short-lived token from Cloudflare…")
        val url = "$workerBase/token".toHttpUrl()
        val request = Request.Builder()
            .url(url)
            .post(okhttp3.RequestBody.create(null, ByteArray(0)))
            .header("X-App-Token", appToken)
            .build()

        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                runOnUiThread { setStatus("Worker network error: ${e.message}") }
            }

            override fun onResponse(call: Call, response: Response) {
                val raw = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    runOnUiThread {
                        setStatus("Worker returned HTTP ${response.code}. Check Worker URL, APP_TOKEN and Worker logs.")
                        appendLog(raw.take(1000))
                    }
                    return
                }
                val data = try { JSONObject(raw) } catch (_: Exception) {
                    runOnUiThread { setStatus("Worker response was not valid JSON.") }
                    return
                }
                val token = data.optString("token")
                val endpoint = data.optString("wsEndpoint")
                val model = data.optString("model", "models/gemini-3.8-live")
                if (token.isBlank() || endpoint.isBlank()) {
                    runOnUiThread { setStatus("Token response is missing token or wsEndpoint.") }
                    return
                }
                runOnUiThread { setStatus("Token received. Opening WebSocket…") }
                openLiveSocket(endpoint, token, model)
            }
        })
    }

    private fun openLiveSocket(endpoint: String, token: String, model: String) {
        // The ephemeral token is sent as the API key for this short-lived connection.
        val request = Request.Builder()
            .url(endpoint)
            .header("x-goog-api-key", token)
            .build()

        socket = client.newWebSocket(request, object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                runOnUiThread { setStatus("WebSocket opened. Sending session setup…") }
                val setup = JSONObject()
                    .put("setup", JSONObject()
                        .put("model", model)
                        .put("generationConfig", JSONObject()
                            .put("responseModalities", org.json.JSONArray().put("AUDIO")))
                        .put("systemInstruction", JSONObject()
                            .put("parts", org.json.JSONArray().put(
                                JSONObject().put("text",
                                    "You are JARVIS, Babun's concise voice assistant. Reply in the user's language: Bengali, Hindi, Hinglish, or English.")
                            )))
                    )
                webSocket.send(setup.toString())
            }

            override fun onMessage(webSocket: WebSocket, text: String) {
                // Log only a small, redacted summary; never show token contents.
                runOnUiThread {
                    appendLog("Server message received (${text.length} chars).")
                    try {
                        val obj = JSONObject(text)
                        if (obj.has("setupComplete")) {
                            setStatus("Gemini Live session setup completed. Connection test passed.")
                        } else if (obj.has("error")) {
                            setStatus("Gemini returned an error; see response summary below.")
                            appendLog(obj.optJSONObject("error")?.optString("message") ?: "API error")
                        } else {
                            setStatus("Connected. Server response received.")
                        }
                    } catch (_: Exception) {
                        setStatus("Connected. Non-JSON message received.")
                    }
                }
            }

            override fun onMessage(webSocket: WebSocket, bytes: ByteString) {
                runOnUiThread { appendLog("Binary message received (${bytes.size} bytes).") }
            }

            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                runOnUiThread {
                    setStatus("WebSocket failed: ${t.message ?: "unknown error"}")
                    response?.let { appendLog("HTTP handshake status: ${it.code}") }
                }
            }

            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                runOnUiThread { setStatus("WebSocket closed ($code): $reason") }
            }
        })
    }

    private fun setStatus(message: String) {
        status.text = message
        appendLog(message)
    }

    private fun appendLog(message: String) {
        logView.append("• $message\n\n")
    }

    override fun onDestroy() {
        socket?.close(1000, "Activity closed")
        client.dispatcher.cancelAll()
        super.onDestroy()
    }
}
