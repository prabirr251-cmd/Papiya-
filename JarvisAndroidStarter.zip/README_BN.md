# JARVIS Android Starter (connection test)

এটি প্রথম ধাপের **starter project**: Cloudflare Worker থেকে ephemeral token নেয় এবং Gemini Live WebSocket-এ session setup পাঠিয়ে সংযোগ পরীক্ষা করে। এটি এখনও সম্পূর্ণ voice assistant নয়—মাইক্রোফোন থেকে অডিও পাঠানো, অডিও প্লে করা, app launching, alarm/timer function execution পরের ধাপে যোগ করতে হবে।

## শুরু করার নিয়ম
1. ZIP extract করে Android Studio-তে `JarvisAndroidStarter` folder Open করো।
2. Gradle sync শেষ হওয়া পর্যন্ত অপেক্ষা করো।
3. `app/src/main/java/com/babun/jarvis/MainActivity.kt` খোলো।
4. `appToken`-এর `PASTE_YOUR_APP_TOKEN_HERE` অংশে নিজের Cloudflare `APP_TOKEN` বসাও। এটি GitHub-এ বা কারও সঙ্গে share কোরো না।
5. Worker-এর URL যদি আলাদা হয়, `workerBase` বদলাও।
6. ফোনে USB debugging দিয়ে Run করো অথবা Build APK করো।

## গুরুত্বপূর্ণ নিরাপত্তা
- Gemini API key এই Android app-এ রাখবে না; সেটি Cloudflare Secret-এ থাকবে।
- আগে কথোপকথনে ephemeral token প্রকাশিত হয়েছে। সেটি short-lived হলেও ভবিষ্যতে token output কখনও share করবে না।
- `APP_TOKEN` অ্যাপের মধ্যে রাখা production-grade security নয়; APK থেকে এটি বের করা সম্ভব। Production app-এর জন্য user authentication/rate limiting দরকার।
- WebSocket handshake/session setup Google-এর বর্তমান Live API protocol এবং তোমার Worker-এর returned endpoint/model-এর সঙ্গে মিলিয়ে বাস্তব ডিভাইসে পরীক্ষা করতে হবে। Build বা connection সফল হয়েছে বলে এই starter-কে আগে থেকেই দাবি করা হচ্ছে না।
